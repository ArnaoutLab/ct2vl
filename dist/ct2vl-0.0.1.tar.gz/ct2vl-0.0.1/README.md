Ct2vl. py is for use with Abbott m2000 as validated at Beth Israel Deaconess Medical Center. If you want to use this at some other site or system, you will want to be sure that efficiency falls linearly with Ct, and measure the appropriate constants.

Please cite:

Arnaout et al. SARS-CoV-2 Testing: The Limit of Detection Matters—The Case for Benchmarking. bioRxiv, In press.



Below are the constants:

m = -0.0283 # slope of line relating efficiency to cycle no (R2=0.82)
b = m*1.41 + (1.379 + 1) # = rho_0 = efficiency + 1
vL = 100 # viral load at LoD, in copies/mL
CtL = 26.06 # Ct value at LoD (result of BIDMC validation)